INSERT INTO `qa_permissions` (`id`, `description`, `permission`, `createdAt`, `updatedAt`) VALUES (1, 'WILDCARD: Full privileges on all the platform', '*', '2020-2-6 08:26:28', '2020-2-6 08:26:28');
INSERT INTO `qa_permissions` (`id`, `description`, `permission`, `createdAt`, `updatedAt`) VALUES (2, 'Asesor-Policies', 'policies:*:*', '2020-2-6 10:15:10', '2020-2-6 10:15:10');
