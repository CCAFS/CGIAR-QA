INSERT INTO `qa_indicator_user` (`id`, `createdAt`, `updatedAt`, `userId`, `indicatorId`) VALUES (2, '2020-2-13 16:14:34', '2020-2-13 16:14:34', 3, 1);
INSERT INTO `qa_indicator_user` (`id`, `createdAt`, `updatedAt`, `userId`, `indicatorId`) VALUES (9, '2020-2-24 09:46:22', '2020-2-24 09:46:22', 3, 3);
INSERT INTO `qa_indicator_user` (`id`, `createdAt`, `updatedAt`, `userId`, `indicatorId`) VALUES (27, '2020-3-12 14:21:38', '2020-3-12 14:21:38', 5, 1);
