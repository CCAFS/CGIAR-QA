INSERT INTO `qa_roles_permissions` (`qa_role`, `qa_permissions`) VALUES (1, 1);
INSERT INTO `qa_roles_permissions` (`qa_role`, `qa_permissions`) VALUES (3, 2);
INSERT INTO `qa_roles_permissions` (`qa_role`, `qa_permissions`) VALUES (4, 2);
