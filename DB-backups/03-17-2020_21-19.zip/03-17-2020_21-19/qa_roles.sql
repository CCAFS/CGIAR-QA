INSERT INTO `qa_roles` (`id`, `createdAt`, `updatedAt`, `acronym`, `is_active`, `description`) VALUES (1, '2020-2-6 08:26:28', '2020-2-6 08:26:28', 'ADM', 1, 'ADMIN');
INSERT INTO `qa_roles` (`id`, `createdAt`, `updatedAt`, `acronym`, `is_active`, `description`) VALUES (3, '2020-2-6 10:16:42', '2020-2-6 10:16:42', 'ASR-POL', 1, 'ASSESSOR');
INSERT INTO `qa_roles` (`id`, `createdAt`, `updatedAt`, `acronym`, `is_active`, `description`) VALUES (4, '2020-3-17 13:06:32', '2020-3-17 13:06:32', 'CRP', 1, 'CRP');
