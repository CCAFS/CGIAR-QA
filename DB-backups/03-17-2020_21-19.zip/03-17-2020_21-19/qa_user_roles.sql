INSERT INTO `qa_user_roles` (`qa_user`, `qa_role`) VALUES (1, 1);
INSERT INTO `qa_user_roles` (`qa_user`, `qa_role`) VALUES (1, 3);
INSERT INTO `qa_user_roles` (`qa_user`, `qa_role`) VALUES (2, 3);
INSERT INTO `qa_user_roles` (`qa_user`, `qa_role`) VALUES (3, 3);
INSERT INTO `qa_user_roles` (`qa_user`, `qa_role`) VALUES (4, 1);
INSERT INTO `qa_user_roles` (`qa_user`, `qa_role`) VALUES (5, 3);
INSERT INTO `qa_user_roles` (`qa_user`, `qa_role`) VALUES (8, 4);
